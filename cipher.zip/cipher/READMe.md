# Mini-Project 1: Classical encryption
## Grant Sackmann

Upload of Samuel Rebelsky's CSC 207 class Mini-Project 1 assignment. 
Implementing the Caesar and Vigenère ciphering  schemes through command-line interface.

## resourcest 
### Stack Overflow
Error Look up and general debugging guidance
### Evening Tutors and Professor Peter-Michael Osera
Conversational help on Maven setup up and JUnit Testing
### Peer Collaboration
Kevin Tang: Assisted with Setting up Testing Environment
Kostiantyn Tsymbol: Collaborated on code debugging